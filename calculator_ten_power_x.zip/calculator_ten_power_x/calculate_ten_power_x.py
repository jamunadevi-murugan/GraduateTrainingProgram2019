"""This module is going to calculate ten power x"""
from __future__ import print_function
import sys


def cal_power_ten(pow_value):
    """This function is used to calulate ten power x value"""
    return 10**pow_value


if __name__ == '__main__':
    try:
        POWER_VALUE = float(sys.argv[1])
        print(cal_power_ten(POWER_VALUE))

    except ValueError:
        print("Error has occured")
