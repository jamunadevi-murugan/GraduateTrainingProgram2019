"""This module is used to unit test the scientific operation (10 power x)"""
import unittest
from calculate_ten_power_x import cal_power_ten


class MyTestCase(unittest.TestCase):
    """This class is used to test the scientific operation 10 power x"""
    def test_pos_power(self):
        """This function is used to unit test the scientific operation 10 power x
         for positive power value"""
        self.assertEqual(cal_power_ten(2), 10**2)

    def test_neg_power(self):
        """This function is used to unit test the scientific operation 10 power x
        for negative power value"""
        self.assertEqual(cal_power_ten(-2), 10**(-2))

    def test_zero_power(self):
        """This function is used to unit test the scientific operation 10 power x
        for zero power value"""
        self.assertEqual(cal_power_ten(0), 10**0)

    def test_pos_dec_power(self):
        """This function is used to unit test the scientific operation 10 power x
        for positive_float power value"""
        self.assertEqual(cal_power_ten(2.2), 10**2.2)

    def test_neg_dec_power(self):
        """This function is used to unit test the scientific operation 10 power x
        for negative_float power value"""
        self.assertEqual(cal_power_ten(-2.2), 10**(-2.2))


if __name__ == '__main__':
    unittest.main()
