"""This module is used for main method"""
from __future__ import print_function
import sys
from src.driver.calculate_ten_power_x import cal_power_ten


def main():
    """This main method is used to call the scientific operation 10 power x"""
    power_value = sys.argv[1]
    print(cal_power_ten(power_value))
    