"""This module is going to calculate ten power x"""
from __future__ import print_function


def cal_power_ten(pow_value):
    """This function is used to calculate ten power x value"""
    try:
        return 10**float(pow_value)
    except ValueError:
        return "Error has occured"
