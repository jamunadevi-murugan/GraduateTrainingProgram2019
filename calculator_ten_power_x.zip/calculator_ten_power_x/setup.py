from setuptools import setup

setup(
    name='ten_power_x_egg',
    version='1.0.1',
    entry_points={'setuptools.installation': ['eggsecutable = src.main.main:main'], },
    data_files=[('.', ['__main__.py'])],

)
