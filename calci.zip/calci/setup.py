from setuptools import setup

setup(
    name='tenpowerx',
    version='1.0.0',
    packages=['src', 'src.code', 'src.main', 'test'],
    url='',
    entry_points={'setuptools.installation': ['eggsecutable = src.main.main:main'], },
    data_files=[('.', ['__main__.py'])],
    license='',
    author='jamunadevi.murugan',
    author_email='',
    description=''
)
