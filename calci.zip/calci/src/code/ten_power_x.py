"""This module is going to calculate ten power x"""
import logging
logging.basicConfig(filename='logger_file.log', level=logging.ERROR,
                    format='%(asctime)s:%(levelname)s:%(message)s', filemode='w')


class CalculatePowerTen:
    """This class is used to calculate the scientific operation ten power x"""
    def __init__(self):
        """This function is used to initialize the calculate function"""
        self.answer = 0

    def cal_power_ten(self, pow_value):
        """This function is used to calculate ten power x value"""
        try:
            self.answer = 10**float(pow_value)
            return self.answer
        except ValueError as value_error:
            logging.error(value_error)
            raise ValueError
