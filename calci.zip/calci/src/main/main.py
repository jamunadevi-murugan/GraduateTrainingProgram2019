"""This module is used for main method"""
from __future__ import print_function
import sys
from src.code.ten_power_x import CalculatePowerTen


def main():
    """This main method is used to call the scientific operation 10 power x"""
    try:
        calculate_power_ten = CalculatePowerTen()
        power_value = sys.argv[1]
        print(calculate_power_ten.cal_power_ten(power_value))
    except ValueError:
        print('Error has occured')
