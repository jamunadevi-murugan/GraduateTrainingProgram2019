"""This module is the main method which call the main function main method"""
from src.main.main import main

if __name__ == '__main__':
    main()
